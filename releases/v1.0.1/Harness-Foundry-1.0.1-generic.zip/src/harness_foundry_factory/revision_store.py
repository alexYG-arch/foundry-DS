"""The existing REVISION_V1 control store, isolated from legacy authoring.

The database format and events are unchanged; no migration or second state
store is created by extracting this implementation.
"""

from contextlib import contextmanager
import json
from pathlib import Path
import sqlite3
from typing import Any, Iterator, Mapping
import uuid

from .build_types import (RequestValidationError, RevisionConflictError,
                          IdempotencyConflictError, canonical_json)

REVISION_CONTROL_EVENT_STORE_TABLE_COLUMNS = {
    "control_events": (
        ("sequence", "INTEGER", 0, 1), ("event_id", "TEXT", 1, 0),
        ("program_id", "TEXT", 1, 0), ("stream_revision", "INTEGER", 1, 0),
        ("event_type", "TEXT", 1, 0), ("payload_json", "TEXT", 1, 0),
        ("created_at", "TEXT", 1, 0),
    ),
    "control_idempotency": (
        ("program_id", "TEXT", 1, 1), ("idempotency_key", "TEXT", 1, 2),
        ("request_json", "TEXT", 1, 0), ("events_json", "TEXT", 1, 0),
        ("created_at", "TEXT", 1, 0),
    ),
}

CONTROL_EVENT_STORE_TRIGGER_SQL: dict[str, str] = {
    "control_events_reject_update": (
        "CREATE TRIGGER control_events_reject_update "
        "BEFORE UPDATE ON control_events BEGIN "
        "SELECT RAISE(ABORT, 'control_events is append-only'); END"
    ),
    "control_events_reject_delete": (
        "CREATE TRIGGER control_events_reject_delete "
        "BEFORE DELETE ON control_events BEGIN "
        "SELECT RAISE(ABORT, 'control_events is append-only'); END"
    ),
}


class RevisionControlEventStore:
    """Revision CAS and literal request idempotency in one append-only SQLite database."""

    _table_columns = REVISION_CONTROL_EVENT_STORE_TABLE_COLUMNS

    def __init__(
        self, database_path: str | Path, *, read_only: bool = False,
        storage_format: str = "REVISION_V1", _allow_dedup: bool = False,
    ) -> None:
        if storage_format != "REVISION_V1":
            raise RequestValidationError("unsupported control event storage format")
        self.storage_format = storage_format
        self.database_path = Path(database_path).expanduser().resolve()
        self.read_only = read_only
        database_existed = self.database_path.exists()
        if read_only and not database_existed:
            raise RequestValidationError(
                "read-only control event store does not exist",
                details={"database_path": str(self.database_path)},
            )
        if database_existed and not _allow_dedup:
            with self._connection() as connection:
                if connection.execute(
                        "SELECT 1 FROM sqlite_master WHERE type='table' AND name='control_source_content'").fetchone():
                    raise RequestValidationError(
                        "store uses REVISION_V1_DEDUP; open it with DedupRevisionControlEventStore",
                        details={"storage_format": "REVISION_V1_DEDUP"},
                    )
        if read_only:
            with self._connection() as connection:
                self._require_exact_existing_schema(connection, self._table_columns)
            return
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize(database_existed=database_existed)

    @contextmanager
    def _connection(self) -> Iterator[sqlite3.Connection]:
        if self.read_only:
            connection = sqlite3.connect(
                self.database_path.as_uri() + "?mode=ro",
                timeout=30.0,
                uri=True,
            )
        else:
            connection = sqlite3.connect(str(self.database_path), timeout=30.0)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA busy_timeout = 30000")
        try:
            yield connection
        finally:
            connection.close()

    def _initialize(self, *, database_existed):
        with self._connection() as connection:
            if database_existed:
                self._require_exact_existing_schema(connection, self._table_columns)
            connection.execute("PRAGMA journal_mode = WAL")
            self._initialize_revision_schema(connection)

    @staticmethod
    def _require_exact_existing_schema(connection: sqlite3.Connection, columns=None) -> None:
        """Fail before WAL, DDL, or event mutation for a non-native database."""

        table_names = {
            str(row[0])
            for row in connection.execute(
                "SELECT name FROM sqlite_master WHERE type = 'table'"
            )
        }
        columns = REVISION_CONTROL_EVENT_STORE_TABLE_COLUMNS if columns is None else columns
        expected_tables = set(columns)
        if not expected_tables.issubset(table_names):
            raise RequestValidationError(
                "existing control event store does not match the native schema",
                details={
                    "expected_tables": sorted(expected_tables),
                    "actual_tables": sorted(table_names),
                    "policy": "REJECT_BEFORE_SCHEMA_OR_JOURNAL_MUTATION",
                },
            )
        for table, expected_columns in columns.items():
            actual_columns = tuple(
                (
                    str(row[1]),
                    str(row[2]).upper(),
                    int(row[3]),
                    int(row[5]),
                )
                for row in connection.execute(f"PRAGMA table_info({table})")
            )
            if actual_columns != expected_columns:
                raise RequestValidationError(
                    "existing control event store does not match the native schema",
                    details={
                        "table": table,
                        "expected_columns": expected_columns,
                        "actual_columns": actual_columns,
                        "policy": "REJECT_BEFORE_SCHEMA_OR_JOURNAL_MUTATION",
                    },
                )
        triggers = {
            str(row[0]): " ".join(str(row[1] or "").split())
            for row in connection.execute(
                "SELECT name, sql FROM sqlite_master WHERE type = 'trigger'"
            )
        }
        for trigger_name, expected_sql in CONTROL_EVENT_STORE_TRIGGER_SQL.items():
            if triggers.get(trigger_name) != " ".join(expected_sql.split()):
                raise RequestValidationError(
                    "existing control event store lacks an exact append-only guard",
                    details={
                        "trigger": trigger_name,
                        "policy": "REJECT_BEFORE_SCHEMA_OR_JOURNAL_MUTATION",
                    },
                )

    @staticmethod
    def _initialize_revision_schema(connection: sqlite3.Connection) -> None:
        connection.executescript("""
            CREATE TABLE IF NOT EXISTS control_events (
                sequence INTEGER PRIMARY KEY AUTOINCREMENT,
                event_id TEXT NOT NULL UNIQUE,
                program_id TEXT NOT NULL,
                stream_revision INTEGER NOT NULL,
                event_type TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                created_at TEXT NOT NULL,
                UNIQUE(program_id, stream_revision)
            );
            CREATE TABLE IF NOT EXISTS control_idempotency (
                program_id TEXT NOT NULL,
                idempotency_key TEXT NOT NULL,
                request_json TEXT NOT NULL,
                events_json TEXT NOT NULL,
                created_at TEXT NOT NULL,
                PRIMARY KEY(program_id, idempotency_key)
            );
            CREATE INDEX IF NOT EXISTS control_events_program_revision
                ON control_events(program_id, stream_revision);
        """)
        for sql in CONTROL_EVENT_STORE_TRIGGER_SQL.values():
            connection.execute(sql.replace("CREATE TRIGGER ", "CREATE TRIGGER IF NOT EXISTS ", 1))
        connection.commit()

    def append_batch(self, program_id, entries, *, idempotency_key, created_at,
                     expected_revision=None, require_new=False, exclusive_program=False,
                     expected_previous_event_hash=None):
        if expected_previous_event_hash is not None:
            raise RequestValidationError("revision streams do not accept event hashes")
        if self.read_only:
            raise RequestValidationError("read-only Control Event Store cannot append events")
        if type(expected_revision) is not int or expected_revision < 0:
            raise RequestValidationError("revision streams require a nonnegative expected_revision")
        if (not isinstance(program_id, str) or not program_id or not isinstance(idempotency_key, str)
                or not idempotency_key or not isinstance(created_at, str) or not created_at
                or not isinstance(entries, (list, tuple)) or not entries):
            raise RequestValidationError("control event batch requires program_id, idempotency_key, time and entries")
        entries, aux = self._prepare_entries(entries)
        normalized = []
        for entry in entries:
            if (not isinstance(entry, Mapping) or set(entry) != {"event_type", "payload"}
                    or not isinstance(entry["event_type"], str) or not entry["event_type"]
                    or not isinstance(entry["payload"], Mapping)):
                raise RequestValidationError("control entries require event_type and an object payload")
            normalized.append({"event_type": entry["event_type"], "payload": dict(entry["payload"])})
        try:
            # Store the request, not a hash of it. JSON types remain significant.
            request_json = json.dumps({"expected_revision": expected_revision, "entries": normalized},
                                      ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
        except (TypeError, ValueError) as exc:
            raise RequestValidationError("control payload must contain finite JSON values") from exc
        normalized = json.loads(request_json)["entries"]
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            if exclusive_program and connection.execute(
                    "SELECT 1 FROM control_events WHERE program_id != ? LIMIT 1", (program_id,)).fetchone():
                raise RevisionConflictError("local controller already belongs to a different Program")
            replay = connection.execute(
                "SELECT request_json, events_json FROM control_idempotency WHERE program_id = ? AND idempotency_key = ?",
                (program_id, idempotency_key)).fetchone()
            if replay is not None:
                if require_new:
                    raise RevisionConflictError("control batch was already reserved; re-read before taking action")
                if replay["request_json"] != request_json:
                    raise IdempotencyConflictError("control idempotency key was reused with different content")
                return json.loads(replay["events_json"])
            revision = connection.execute(
                "SELECT COALESCE(MAX(stream_revision), 0) FROM control_events WHERE program_id = ?", (program_id,)).fetchone()[0]
            if expected_revision != revision:
                raise RevisionConflictError("control event stream changed before append",
                                         details={"expected_revision": expected_revision, "actual_revision": revision})
            self._append_aux(connection, normalized, aux)
            appended = []
            for entry in normalized:
                revision += 1
                event = {"schema_version": "REVISION_V1", "event_id": f"CEVT-{uuid.uuid4().hex.upper()}",
                         "program_id": program_id, "stream_revision": revision, **entry, "created_at": created_at}
                connection.execute("""INSERT INTO control_events(event_id, program_id, stream_revision,
                    event_type, payload_json, created_at) VALUES (?, ?, ?, ?, ?, ?)""",
                    (event["event_id"], program_id, revision, entry["event_type"], canonical_json(entry["payload"]), created_at))
                appended.append(event)
            connection.execute("""INSERT INTO control_idempotency(program_id, idempotency_key, request_json,
                events_json, created_at) VALUES (?, ?, ?, ?, ?)""",
                (program_id, idempotency_key, request_json, canonical_json(appended), created_at))
            connection.commit()
            return appended


    def _prepare_entries(self, entries):
        """Store-format hook; returns ``(entries, aux)``.

        ``aux`` travels with this call into ``_append_aux`` so concurrent
        appends on one instance never share mutable state. Default keeps
        bytes unchanged and carries nothing.
        """
        return entries, None

    def _append_aux(self, connection, entries, aux):
        """Store-format hook inside the append transaction."""
        return None

    def idempotent_events(self, program_id, idempotency_key):
        """Read an existing reservation without reserving another effect."""
        with self._connection() as connection:
            row = connection.execute(
                "SELECT events_json FROM control_idempotency WHERE program_id = ? AND idempotency_key = ?",
                (program_id, idempotency_key)).fetchone()
        return json.loads(row["events_json"]) if row is not None else None

    _idempotent_events = idempotent_events

    def get_event(self, program_id, event_id):
        """Read one event by its Program-scoped identity, without history expansion."""
        with self._connection() as connection:
            row = connection.execute(
                "SELECT * FROM control_events WHERE program_id = ? AND event_id = ?",
                (program_id, event_id)).fetchone()
        return self._row_event(row) if row is not None else None

    def event_count(self, program_id):
        with self._connection() as connection:
            return int(connection.execute(
                "SELECT COUNT(*) FROM control_events WHERE program_id = ?", (program_id,)).fetchone()[0])

    def _row_event(self, row):
        return {"schema_version": "REVISION_V1", "event_id": str(row["event_id"]),
                "program_id": str(row["program_id"]), "stream_revision": int(row["stream_revision"]),
                "event_type": str(row["event_type"]), "payload": json.loads(str(row["payload_json"])),
                "created_at": str(row["created_at"])}

    def list_events_by_types(self, program_id, event_types, *, after_revision=0, up_to_revision=None, limit=None):
        """Read only the control event families needed by one decision.

        ``up_to_revision`` pins the read to a revision obtained beforehand (for
        example from ``event_count``), so several typed reads on separate
        connections describe one consistent prefix of the stream.
        """
        types = tuple(event_types)
        if not types or any(not isinstance(kind, str) or not kind for kind in types):
            raise RequestValidationError("control event types must be nonempty text")
        if type(after_revision) is not int or after_revision < 0:
            raise RequestValidationError("after_revision must be nonnegative")
        if up_to_revision is not None and (type(up_to_revision) is not int or up_to_revision < after_revision):
            raise RequestValidationError("up_to_revision must be an integer not below after_revision")
        marks = ",".join("?" for _ in types)
        sql = (f"SELECT * FROM control_events WHERE program_id = ? AND stream_revision > ? "
               f"AND event_type IN ({marks})")
        args = [program_id, after_revision, *types]
        if up_to_revision is not None:
            sql += " AND stream_revision <= ?"; args.append(up_to_revision)
        sql += " ORDER BY stream_revision"
        if limit is not None:
            if type(limit) is not int or limit <= 0:
                raise RequestValidationError("limit must be positive")
            sql += " LIMIT ?"; args.append(limit)
        with self._connection() as connection:
            rows = connection.execute(sql, args).fetchall()
        return [self._row_event(row) for row in rows]

    def list_events_by_payload_field(self, program_id, event_type, field, value, *, limit=None):
        """Events of one type whose top-level payload ``field`` equals ``value``.

        ``value=None`` selects events where the field is absent/null. The match
        runs inside SQLite (``json_extract``), so callers can locate a capture
        by a recorded digest without deserializing every stored body.
        """
        if not isinstance(event_type, str) or not event_type:
            raise RequestValidationError("control event type must be nonempty text")
        if not isinstance(field, str) or not field or not field.replace("_", "").isalnum():
            raise RequestValidationError("payload field must be a simple identifier")
        if value is not None and not isinstance(value, (str, int)):
            raise RequestValidationError("payload field value must be text or an integer")
        sql = f"SELECT * FROM control_events WHERE program_id = ? AND event_type = ? AND json_extract(payload_json, '$.{field}')"
        args = [program_id, event_type]
        if value is None:
            sql += " IS NULL"
        else:
            sql += " = ?"; args.append(value)
        sql += " ORDER BY stream_revision"
        if limit is not None:
            if type(limit) is not int or limit <= 0:
                raise RequestValidationError("limit must be positive")
            sql += " LIMIT ?"; args.append(limit)
        with self._connection() as connection:
            rows = connection.execute(sql, args).fetchall()
        return [self._row_event(row) for row in rows]

    def iter_events(self, program_id, *, batch_size=500):
        """Yield a Program's events in revision order without holding them all."""
        if type(batch_size) is not int or batch_size <= 0:
            raise RequestValidationError("batch_size must be positive")
        after = 0
        while True:
            with self._connection() as connection:
                rows = connection.execute(
                    "SELECT * FROM control_events WHERE program_id = ? AND stream_revision > ? "
                    "ORDER BY stream_revision LIMIT ?", (program_id, after, batch_size)).fetchall()
            if not rows:
                return
            for event in self._hydrate_rows([self._row_event(row) for row in rows]):
                yield event
            after = int(rows[-1]["stream_revision"])

    def _hydrate_rows(self, events):
        """Store-format hook for batched readers; default returns events unchanged."""
        return events

    def list_idempotency_keys(self, program_id):
        with self._connection() as connection:
            return [str(row[0]) for row in connection.execute(
                "SELECT idempotency_key FROM control_idempotency WHERE program_id = ? ORDER BY idempotency_key",
                (program_id,))]

    def list_events(self, program_id, *, elide=None):
        """Read a Program's whole stream in order.

        ``elide`` maps an event type to payload fields that are removed inside
        SQLite (``json_remove``) before the row reaches Python; the payload then
        carries ``elided_fields`` naming them. Revision arithmetic, ordering and
        every other payload stay intact, so control projections keep working
        while multi-megabyte bodies are neither parsed nor hydrated. Callers
        that need a body read that one event with ``get_event``.
        """
        if not elide:
            with self._connection() as connection:
                rows = connection.execute(
                    "SELECT * FROM control_events WHERE program_id = ? ORDER BY stream_revision",
                    (program_id,),
                ).fetchall()
            return [self._row_event(row) for row in rows]
        if not isinstance(elide, Mapping) or not elide:
            raise RequestValidationError("elide must map event types to payload field names")
        cases, args = [], []
        for event_type, fields in elide.items():
            fields = tuple(fields)
            if (not isinstance(event_type, str) or not event_type or not fields
                    or any(not isinstance(f, str) or not f or not f.replace("_", "").isalnum() for f in fields)):
                raise RequestValidationError("elide needs nonempty event types and simple payload field names")
            paths = ", ".join(f"'$.{field}'" for field in fields)
            cases.append(f"WHEN event_type = ? THEN json_remove(payload_json, {paths})")
            args.append(event_type)
        sql = (f"SELECT sequence, event_id, program_id, stream_revision, event_type, created_at, "
               f"CASE {' '.join(cases)} ELSE payload_json END AS payload_json "
               f"FROM control_events WHERE program_id = ? ORDER BY stream_revision")
        with self._connection() as connection:
            rows = connection.execute(sql, [*args, program_id]).fetchall()
        events = []
        for row in rows:
            event = self._row_event(row)
            if event["event_type"] in elide:
                event["payload"]["elided_fields"] = sorted(elide[event["event_type"]])
            events.append(event)
        return events

    def list_program_ids(self):
        with self._connection() as connection:
            return [str(row[0]) for row in connection.execute(
                "SELECT DISTINCT program_id FROM control_events ORDER BY program_id")]

    def verify_stream(self, program_id):
        events = self.list_events(program_id)
        errors = [{"code": "CONTROL_EVENT_REVISION_GAP"} for revision, event in enumerate(events, 1)
                  if event["stream_revision"] != revision]
        return {"schema_version": "REVISION_V1", "status": "FAIL" if errors else "PASS",
                "program_id": program_id, "event_count": len(events), "errors": errors,
                "last_revision": events[-1]["stream_revision"] if events else 0,
                "content_integrity_verified": False}
